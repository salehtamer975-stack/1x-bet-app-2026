package com.example.myfirstapp

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF1769FF)
private val Navy = Color(0xFF102A56)
private val Pale = Color(0xFFF4F8FF)
private val Green = Color(0xFF16A36A)
private const val DEMO_WALLET = "01019676173"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { SportsDemoApp() } }
    }
}

data class Match(val league: String, val home: String, val away: String, val score: String, val status: String)

private val demoMatches = listOf(
    Match("الدوري المصري", "الأهلي", "الزمالك", "2 - 1", "انتهت • مثال تجريبي"),
    Match("الدوري الإنجليزي", "ليفربول", "مانشستر سيتي", "1 - 1", "انتهت • مثال تجريبي"),
    Match("الدوري الإسباني", "ريال مدريد", "برشلونة", "—", "قادمة • مثال تجريبي"),
    Match("دوري أبطال أوروبا", "بايرن ميونخ", "باريس سان جيرمان", "—", "قادمة • مثال تجريبي")
)

@Composable
fun SportsDemoApp() {
    var selectedTab by remember { mutableStateOf("الرئيسية") }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    var screen by remember { mutableStateOf("home") }
    var showNotice by remember { mutableStateOf(false) }
    var balance by remember { mutableStateOf(0) }

    Scaffold(
        containerColor = Pale,
        bottomBar = {
            if (screen == "home" || screen == "matches" || screen == "favorites") {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = screen == "home", onClick = { screen = "home"; selectedTab = "الرئيسية" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
                    NavigationBarItem(selected = screen == "matches", onClick = { screen = "matches"; selectedTab = "المباريات" }, icon = { Icon(Icons.Default.SportsSoccer, null) }, label = { Text("المباريات") })
                    NavigationBarItem(selected = screen == "favorites", onClick = { screen = "favorites"; selectedTab = "المفضلة" }, icon = { Icon(Icons.Default.Star, null) }, label = { Text("المفضلة") })
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFFDCE9FF), Pale, Color.White)))
                .padding(padding)
        ) {
            Header(onAccount = { screen = "account" })
            when (screen) {
                "home" -> HomeContent(
                    matches = demoMatches.take(2), balance = balance, favorites = favorites,
                    onFavorite = { name -> favorites = if (name in favorites) favorites - name else favorites + name },
                    onShowAll = { screen = "matches" }, onDeposit = { screen = "deposit" }, onInfo = { showNotice = true }, onCrashOpen = { screen = "crash" }
                )
                "matches" -> MatchList("كل المباريات", demoMatches, favorites) { name -> favorites = if (name in favorites) favorites - name else favorites + name }
                "favorites" -> {
                    val fav = demoMatches.filter { it.home in favorites || it.away in favorites }
                    if (fav.isEmpty()) EmptyFavorites() else MatchList("المفضلة", fav, favorites) { name -> favorites = if (name in favorites) favorites - name else favorites + name }
                }
                 "account" -> AccountScreen(balance, onBack = { screen = "home" }, onDeposit = { screen = "deposit" }, onWithdraw = { screen = "withdraw" })
                "deposit" -> DepositScreen(onBack = { screen = "account" }, onSubmitted = { screen = "account"; showNotice = true })
                "withdraw" -> WithdrawScreen(onBack = { screen = "account" }, onSubmitted = { screen = "account"; showNotice = true })
                "crash" -> CrashGameScreen(onBack = { screen = "home" })
            }
        }
    }
    if (showNotice) {
        AlertDialog(onDismissRequest = { showNotice = false }, title = { Text("نموذج تجريبي فقط") },
            text = { Text("التطبيق للعرض والتجربة فقط. لا توجد تحويلات مالية حقيقية، ولا يتم التحقق من أي عملية أو إضافة رصيد فعلي.") },
            confirmButton = { TextButton(onClick = { showNotice = false }) { Text("تمام") } })
    }
}

@Composable
private fun Header(onAccount: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 18.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).background(Blue, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Text("1X", color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("1X BET", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
            Text("نسخة رياضية تجريبية", color = Color(0xFFB8CEFF), fontSize = 12.sp)
        }
        IconButton(onClick = onAccount) { Icon(Icons.Default.AccountBalanceWallet, contentDescription = "الحساب", tint = Color.White) }
        Icon(Icons.Default.EmojiEvents, contentDescription = "رياضة", tint = Color(0xFFFFD166), modifier = Modifier.size(27.dp))
    }
}

@Composable
private fun HomeContent(matches: List<Match>, balance: Int, favorites: Set<String>, onFavorite: (String) -> Unit, onShowAll: () -> Unit, onDeposit: () -> Unit, onInfo: () -> Unit, onCrashOpen: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("🚀 CRASH • كراش", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text("لعبة محاكاة برصيد افتراضي فقط", color = Color(0xFFB8CEFF), fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = onCrashOpen, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF7626))) { Text("افتح لعبة كراش") }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Blue), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("أهلاً بيك 👋", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("رصيد تجريبي", color = Color(0xFFDCE9FF), modifier = Modifier.padding(top = 12.dp))
                    Text("$balance ج.م", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onDeposit, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Blue)) { Text("إيداع تجريبي") }
                    Text("لا توجد معاملات مالية حقيقية", color = Color(0xFFE6EEFF), fontSize = 11.sp)
                }
            }
        }
        item { Row(verticalAlignment = Alignment.CenterVertically) {
            Text("مباريات مختارة", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy, modifier = Modifier.weight(1f))
            TextButton(onClick = onShowAll) { Text("عرض الكل") }
        } }
        items(matches) { MatchCard(it, favorites, onFavorite) }
        item { TextButton(onClick = onInfo, modifier = Modifier.fillMaxWidth()) { Text("عن التطبيق والبيانات التجريبية") } }
    }
}

@Composable
private fun AccountScreen(balance: Int, onBack: () -> Unit, onDeposit: () -> Unit, onWithdraw: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Text(" رجوع") }
        Text("حسابي", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Navy)
        Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Text("الرصيد التجريبي", color = Color(0xFFB8CEFF))
                Text("$balance ج.م", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onDeposit, modifier = Modifier.fillMaxWidth()) { Text("تعبئة الحساب") }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onWithdraw, modifier = Modifier.fillMaxWidth()) { Text("سحب") }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("طرق الإيداع (عرض تجريبي)", fontWeight = FontWeight.Bold, color = Navy, fontSize = 18.sp)
                Spacer(Modifier.height(12.dp))
                Text("🔴  فودافون كاش", color = Navy)
                Text("🟠  طرق دفع أخرى — غير مفعلة", color = Color.Gray, modifier = Modifier.padding(top = 12.dp))
            }
        }
        Text("تنبيه: لن يتم إرسال أو استقبال أموال من خلال هذا التطبيق.", color = Color(0xFF64748B), fontSize = 12.sp)
    }
}

@Composable
private fun DepositScreen(onBack: () -> Unit, onSubmitted: () -> Unit) {
    val context = LocalContext.current
    var amount by remember { mutableStateOf("100") }
    var phone by remember { mutableStateOf("") }
    var receipt by remember { mutableStateOf<Uri?>(null) }
    var receiptName by remember { mutableStateOf("لم يتم اختيار صورة") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        receipt = uri
        receiptName = if (uri != null) "تم اختيار صورة للتحويل التجريبي" else "لم يتم اختيار صورة"
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Text(" رجوع للحساب") } }
        item { Text("إيداع عبر فودافون كاش", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF2F2)), shape = RoundedCornerShape(14.dp)) {
                Text("واجهة تجريبية فقط — لا تحوّل أموالًا لهذا الرقم من خلال التطبيق. الرقم المعروض لم يتم التحقق من ملكيته أو صلاحيته.", color = Color(0xFF9F2424), modifier = Modifier.padding(14.dp), fontSize = 12.sp)
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("رقم المحفظة (للعرض فقط)", color = Color.Gray, fontSize = 13.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(DEMO_WALLET, color = Navy, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Button(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("رقم تجريبي", DEMO_WALLET))
                            Toast.makeText(context, "تم نسخ الرقم التجريبي", Toast.LENGTH_SHORT).show()
                        }) { Text("نسخ") }
                    }
                }
            }
        }
        item { Text("اختار مبلغًا تجريبيًا", fontWeight = FontWeight.Bold, color = Navy) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("50", "100", "200", "500").forEach { value ->
                    FilterChip(selected = amount == value, onClick = { amount = value }, label = { Text("$value ج.م") })
                }
            }
        }
        item {
            OutlinedTextField(value = amount, onValueChange = { amount = it.filter(Char::isDigit).take(6) }, label = { Text("المبلغ (تجريبي)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        }
        item {
            OutlinedTextField(value = phone, onValueChange = { phone = it.filter(Char::isDigit).take(11) }, label = { Text("رقم الهاتف (اختياري للعرض)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
        }
        item {
            OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Image, null); Text("  اختيار صورة إيصال تجريبي")
            }
            Text(receiptName, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
        }
        item {
            Button(onClick = {
                Toast.makeText(context, "تم تسجيل الطلب كعرض تجريبي فقط — لم يتم تحويل أو إضافة أي أموال", Toast.LENGTH_LONG).show()
                onSubmitted()
            }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text("عرض إرسال طلب تجريبي") }
        }
        item { Text("هذا الزر لا يرسل بيانات إلى خادم ولا ينفّذ تحويلًا أو إيداعًا حقيقيًا.", color = Color(0xFF64748B), fontSize = 12.sp, textAlign = TextAlign.Center) }
    }
}

@Composable
private fun MatchList(title: String, matches: List<Match>, favorites: Set<String>, onFavorite: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy, modifier = Modifier.padding(bottom = 4.dp)) }
        items(matches) { MatchCard(it, favorites, onFavorite) }
        item { Text("تنبيه: النتائج هنا تجريبية وغير متصلة بمصدر مباشر.", color = Color(0xFF64748B), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(12.dp)) }
    }
}

@Composable
private fun MatchCard(match: Match, favorites: Set<String>, onFavorite: (String) -> Unit) {
    val isFavorite = match.home in favorites || match.away in favorites
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(Green, CircleShape))
                Spacer(Modifier.width(7.dp))
                Text(match.league, color = Color(0xFF64748B), fontSize = 12.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { onFavorite(match.home); onFavorite(match.away) }) {
                    Icon(Icons.Default.Star, contentDescription = "تبديل المفضلة", tint = if (isFavorite) Color(0xFFFFB800) else Color(0xFF9AA8BD))
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(match.home, color = Navy, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(match.score, color = Blue, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                Text(match.away, color = Navy, fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Text(match.status, color = Color(0xFF64748B), fontSize = 11.sp)
        }
    }
}

@Composable
private fun EmptyFavorites() {
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Star, null, tint = Blue, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(12.dp))
        Text("لسه مفيش فرق في المفضلة", color = Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("افتح المباريات واضغط على النجمة لإضافة فريق.", color = Color(0xFF64748B), textAlign = TextAlign.Center)
    }
}
